# Nexora Fit — Android

Este projeto transforma o Nexora Fit em um app Android usando WebView.

## Salvamento local
Os registros são mantidos pelo armazenamento local do WebView (`localStorage`). Não há servidor, login ou banco de dados online.

- Funciona sem internet depois de instalado.
- Os dados permanecem no aparelho enquanto o app e os dados dele não forem apagados.
- Desinstalar o app pode apagar os dados locais.

## Gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitada.
3. Use **Build > Build APK(s)**.
4. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

O conteúdo do site está em `app/src/main/assets/index.html`.
